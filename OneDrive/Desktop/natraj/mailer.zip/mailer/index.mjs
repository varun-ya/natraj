import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import nodemailer from "nodemailer";

const dynamoDb = new DynamoDBClient({ region: "us-east-1" }); // DynamoDB region

export const handler = async (event) => {
  try {
    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const { email, website } = body;

    if (!email || !website) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "email and website are required" }),
      };
    }

    // 1. Save to DynamoDB
    const params = new PutItemCommand({
      TableName: "mails",
      Item: {
        email_id: { S: email }, // ✅ Primary Key
        website: { S: website },
        createdAt: { S: new Date().toISOString() },
      },
    });
    await dynamoDb.send(params);

    // 2. Prepare email content
    let subject, htmlBody;
    if (website === "natraj") {
      subject = "Welcome to Natraj!";
      htmlBody = `<h2>🙏 Welcome to Natraj</h2>
                  <p>Thanks for registering with <b>Natraj</b>. We’ll keep you updated!</p>
                  <p>Your registered email: ${email}</p>`;
    } else if (website === "osmium") {
      subject = "Welcome to Osmium!";
      htmlBody = `<h2>🚀 Welcome to Osmium</h2>
                  <p>Thanks for joining <b>Osmium</b>. Stay tuned for exciting updates!</p>
                  <p>Your registered email: ${email}</p>`;
    } else {
      subject = "Welcome!";
      htmlBody = `<h2>Hello 👋</h2>
                  <p>Thanks for registering with us!</p>
                  <p>Your registered email: ${email}</p>`;
    }

    // 3. Setup Nodemailer (SMTP with your Gmail)
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for 587
      auth: {
        user: "navchetna.official.llp@gmail.com", // ✅ your Gmail
        pass: "dugfka aonfk xyfei", // ✅ your Gmail App Password
      },
    });

    // 4. Send email
    await transporter.sendMail({
      from: `"Navchetna Team" <navchetna.official.llp@gmail.com>`,
      to: email,
      subject,
      html: htmlBody,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "✅ Email stored in DB and confirmation sent successfully",
      }),
    };
  } catch (err) {
    console.error("Lambda Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "❌ Internal Server Error",
        error: err.message,
      }),
    };
  }
};
